# Scale Coach for Android

A voice-first major-scale practice app modeled after conversational scale drills.

## What version 1 does

- Randomly quizzes all 15 conventional major-key spellings.
- Speaks the prompt aloud with Android Text-to-Speech.
- Lets you answer with your voice using the phone's speech recognizer.
- Understands common forms such as `C sharp`, `F#`, `B flat`, and speech-recognition variants like `bee flat`.
- Checks the exact theoretical note spelling, so E-sharp and F are not treated as the same answer when spelling matters.
- Tells you the first note that needs correcting.
- Lets you retry the same scale, hear the correct answer, or move to the next scale.
- Keeps a simple score and streak.
- Uses large, high-contrast controls and does not require a separate account.

## Open and build in Android Studio

1. Unzip the project.
2. Open Android Studio and choose **Open**.
3. Select the `ScaleCoachAndroid` folder.
4. Let Android Studio finish its Gradle sync and install any requested Android SDK components.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press **Run**.

To make an APK in Android Studio, use **Build > Build APK(s)** (wording varies by Android Studio version).

## Notes

- Speech recognition is provided by the recognition service installed on the Android phone, usually Google's speech service on many devices.
- The first release focuses on major scales. Natural minor, harmonic minor, melodic minor, interval drills, and chord drills can be added next.

## Build without Android Studio (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`.
Upload the project contents to a GitHub repository, open **Actions**, run **Build Scale Coach APK**, then download the **ScaleCoach-APK** artifact. Inside is `app-debug.apk`, which can be installed on an Android phone after allowing installs from the browser or Files app used to open it.

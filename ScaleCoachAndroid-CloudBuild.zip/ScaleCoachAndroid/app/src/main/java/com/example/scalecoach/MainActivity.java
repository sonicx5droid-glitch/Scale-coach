package com.example.scalecoach;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final int SPEECH_REQUEST_CODE = 1001;

    private TextView promptText;
    private TextView scoreText;
    private TextView heardText;
    private TextView resultText;
    private Button tryAgainButton;

    private TextToSpeech tts;
    private boolean ttsReady = false;

    private final Random random = new Random();
    private int currentScaleIndex = -1;
    private int lastScaleIndex = -1;
    private int correctCount = 0;
    private int attemptCount = 0;
    private int streak = 0;
    private boolean alreadyScoredCurrentQuestion = false;

    private static class Scale {
        final String name;
        final String[] notes;

        Scale(String name, String... notes) {
            this.name = name;
            this.notes = notes;
        }
    }

    // Fifteen conventional major-key spellings, including sharp and flat keys.
    private final List<Scale> scales = Arrays.asList(
            new Scale("C major", "C", "D", "E", "F", "G", "A", "B", "C"),
            new Scale("G major", "G", "A", "B", "C", "D", "E", "F#", "G"),
            new Scale("D major", "D", "E", "F#", "G", "A", "B", "C#", "D"),
            new Scale("A major", "A", "B", "C#", "D", "E", "F#", "G#", "A"),
            new Scale("E major", "E", "F#", "G#", "A", "B", "C#", "D#", "E"),
            new Scale("B major", "B", "C#", "D#", "E", "F#", "G#", "A#", "B"),
            new Scale("F-sharp major", "F#", "G#", "A#", "B", "C#", "D#", "E#", "F#"),
            new Scale("C-sharp major", "C#", "D#", "E#", "F#", "G#", "A#", "B#", "C#"),
            new Scale("F major", "F", "G", "A", "Bb", "C", "D", "E", "F"),
            new Scale("B-flat major", "Bb", "C", "D", "Eb", "F", "G", "A", "Bb"),
            new Scale("E-flat major", "Eb", "F", "G", "Ab", "Bb", "C", "D", "Eb"),
            new Scale("A-flat major", "Ab", "Bb", "C", "Db", "Eb", "F", "G", "Ab"),
            new Scale("D-flat major", "Db", "Eb", "F", "Gb", "Ab", "Bb", "C", "Db"),
            new Scale("G-flat major", "Gb", "Ab", "Bb", "Cb", "Db", "Eb", "F", "Gb"),
            new Scale("C-flat major", "Cb", "Db", "Eb", "Fb", "Gb", "Ab", "Bb", "Cb")
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        promptText = findViewById(R.id.promptText);
        scoreText = findViewById(R.id.scoreText);
        heardText = findViewById(R.id.heardText);
        resultText = findViewById(R.id.resultText);
        tryAgainButton = findViewById(R.id.tryAgainButton);

        Button speakButton = findViewById(R.id.speakButton);
        Button repeatButton = findViewById(R.id.repeatButton);
        Button showAnswerButton = findViewById(R.id.showAnswerButton);
        Button nextButton = findViewById(R.id.nextButton);

        tts = new TextToSpeech(this, this);

        speakButton.setOnClickListener(v -> startVoiceAnswer());
        repeatButton.setOnClickListener(v -> speakPrompt());
        showAnswerButton.setOnClickListener(v -> showAndSpeakAnswer());
        nextButton.setOnClickListener(v -> chooseNextScale());
        tryAgainButton.setOnClickListener(v -> {
            heardText.setText("—");
            resultText.setText("Okay. Try the same scale again.");
            startVoiceAnswer();
        });

        chooseNextScale();
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.US);
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            tts.setSpeechRate(0.90f);
            if (ttsReady) {
                speakPrompt();
            }
        }
    }

    private void chooseNextScale() {
        if (scales.size() > 1) {
            do {
                currentScaleIndex = random.nextInt(scales.size());
            } while (currentScaleIndex == lastScaleIndex);
        } else {
            currentScaleIndex = 0;
        }
        lastScaleIndex = currentScaleIndex;
        alreadyScoredCurrentQuestion = false;

        Scale scale = scales.get(currentScaleIndex);
        promptText.setText("Give me the " + scale.name + " scale.");
        heardText.setText("—");
        resultText.setText("Say all 8 notes, including the repeated top note.");
        tryAgainButton.setVisibility(View.GONE);
        speakPrompt();
    }

    private void speakPrompt() {
        if (!ttsReady || currentScaleIndex < 0) return;
        Scale scale = scales.get(currentScaleIndex);
        String spokenName = scale.name
                .replace("F-sharp", "F sharp")
                .replace("C-sharp", "C sharp")
                .replace("B-flat", "B flat")
                .replace("E-flat", "E flat")
                .replace("A-flat", "A flat")
                .replace("D-flat", "D flat")
                .replace("G-flat", "G flat")
                .replace("C-flat", "C flat");
        speak("Give me the " + spokenName + " scale.");
    }

    private void startVoiceAnswer() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say the scale notes in order");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        try {
            startActivityForResult(intent, SPEECH_REQUEST_CODE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this,
                    "No speech recognition service is available on this phone.",
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SPEECH_REQUEST_CODE || resultCode != RESULT_OK || data == null) {
            return;
        }

        ArrayList<String> candidates = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (candidates == null || candidates.isEmpty()) {
            resultText.setText("I didn't catch that. Try again.");
            tryAgainButton.setVisibility(View.VISIBLE);
            return;
        }

        Scale scale = scales.get(currentScaleIndex);
        ParsedAnswer best = null;
        for (String candidate : candidates) {
            List<String> parsed = parseNotes(candidate);
            ParsedAnswer scored = scoreCandidate(candidate, parsed, scale.notes);
            if (best == null || scored.matchCount > best.matchCount) {
                best = scored;
            }
        }

        if (best == null) return;
        heardText.setText(best.notes.isEmpty() ? best.rawText : joinPretty(best.notes));
        gradeAnswer(best.notes, scale);
    }

    private static class ParsedAnswer {
        final String rawText;
        final List<String> notes;
        final int matchCount;

        ParsedAnswer(String rawText, List<String> notes, int matchCount) {
            this.rawText = rawText;
            this.notes = notes;
            this.matchCount = matchCount;
        }
    }

    private ParsedAnswer scoreCandidate(String raw, List<String> notes, String[] expected) {
        int matches = 0;
        int n = Math.min(notes.size(), expected.length);
        for (int i = 0; i < n; i++) {
            if (notes.get(i).equals(expected[i])) matches++;
        }
        return new ParsedAnswer(raw, notes, matches);
    }

    private void gradeAnswer(List<String> answer, Scale scale) {
        boolean correct = answer.size() == scale.notes.length;
        int firstWrong = -1;

        int n = Math.min(answer.size(), scale.notes.length);
        for (int i = 0; i < n; i++) {
            if (!answer.get(i).equals(scale.notes[i])) {
                correct = false;
                firstWrong = i;
                break;
            }
        }
        if (firstWrong == -1 && answer.size() != scale.notes.length) {
            firstWrong = n;
        }

        if (!alreadyScoredCurrentQuestion) {
            attemptCount++;
            alreadyScoredCurrentQuestion = true;
            if (correct) {
                correctCount++;
                streak++;
            } else {
                streak = 0;
            }
            updateScore();
        }

        if (correct) {
            resultText.setText("Correct! Nice job. Tap Next Scale when you're ready.");
            tryAgainButton.setVisibility(View.GONE);
            speak("Correct. Nice job.");
        } else {
            String message;
            if (answer.isEmpty()) {
                message = "I couldn't identify the note names. Try saying them slowly, one note at a time.";
            } else if (firstWrong >= scale.notes.length) {
                message = "You gave extra notes. The correct answer is " + joinPretty(Arrays.asList(scale.notes)) + ".";
            } else if (firstWrong >= answer.size()) {
                message = "You stopped after " + answer.size() + " notes. The next note should be "
                        + prettyNote(scale.notes[firstWrong]) + ".";
            } else {
                message = "Almost. Note " + (firstWrong + 1) + " should be "
                        + prettyNote(scale.notes[firstWrong]) + ", not "
                        + prettyNote(answer.get(firstWrong)) + ". Try it again.";
            }
            resultText.setText(message);
            tryAgainButton.setVisibility(View.VISIBLE);
            speak(message.replace("#", " sharp "));
        }
    }

    private void updateScore() {
        scoreText.setText("Score: " + correctCount + " / " + attemptCount + "    Streak: " + streak);
    }

    private void showAndSpeakAnswer() {
        Scale scale = scales.get(currentScaleIndex);
        String answer = joinPretty(Arrays.asList(scale.notes));
        resultText.setText("Correct answer: " + answer);
        speak("The correct answer is " + notesForSpeech(scale.notes));
    }

    private void speak(String text) {
        if (!ttsReady) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "scale-coach");
    }

    private String notesForSpeech(String[] notes) {
        List<String> spoken = new ArrayList<>();
        for (String note : notes) {
            if (note.endsWith("#")) {
                spoken.add(note.substring(0, 1) + " sharp");
            } else if (note.endsWith("b")) {
                spoken.add(note.substring(0, 1) + " flat");
            } else {
                spoken.add(note);
            }
        }
        return String.join(", ", spoken);
    }

    private String joinPretty(List<String> notes) {
        List<String> pretty = new ArrayList<>();
        for (String note : notes) pretty.add(prettyNote(note));
        return String.join(" – ", pretty);
    }

    private String prettyNote(String note) {
        return note.replace("#", "♯").replace("b", "♭");
    }

    /**
     * Converts speech-recognition text into note spellings such as C, F#, or Bb.
     * It accepts common speech-engine variants like "C sharp", "C#", "B flat",
     * "bee flat", "see sharp", and hyphenated accidental names.
     */
    private List<String> parseNotes(String raw) {
        String s = raw.toLowerCase(Locale.US)
                .replace("♯", " sharp ")
                .replace("♭", " flat ")
                .replace("#", " sharp ")
                .replaceAll("([a-g])-flat", "$1 flat")
                .replaceAll("([a-g])-sharp", "$1 sharp")
                .replaceAll("[^a-z ]", " ")
                .replaceAll("\\s+", " ")
                .trim();

        if (s.isEmpty()) return new ArrayList<>();

        Map<String, String> letterMap = new HashMap<>();
        letterMap.put("a", "A");
        letterMap.put("ay", "A");
        letterMap.put("b", "B");
        letterMap.put("be", "B");
        letterMap.put("bee", "B");
        letterMap.put("c", "C");
        letterMap.put("see", "C");
        letterMap.put("sea", "C");
        letterMap.put("d", "D");
        letterMap.put("dee", "D");
        letterMap.put("e", "E");
        letterMap.put("ee", "E");
        letterMap.put("f", "F");
        letterMap.put("ef", "F");
        letterMap.put("eff", "F");
        letterMap.put("g", "G");
        letterMap.put("gee", "G");

        String[] tokens = s.split(" ");
        List<String> notes = new ArrayList<>();

        for (int i = 0; i < tokens.length; i++) {
            String token = tokens[i];
            String letter = letterMap.get(token);
            if (letter == null) continue;

            String accidental = "";
            if (i + 1 < tokens.length) {
                if (tokens[i + 1].equals("sharp")) {
                    accidental = "#";
                    i++;
                } else if (tokens[i + 1].equals("flat")) {
                    accidental = "b";
                    i++;
                } else if (tokens[i + 1].equals("natural")) {
                    i++;
                }
            }
            notes.add(letter + accidental);
        }

        return notes;
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
